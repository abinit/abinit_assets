#!/usr/bin/env python3
"""Compare four nstep=1 MPI layouts using the reference script's definitions.

Runs are aligned by np_spkpt, not by the k*.abi filename or total MPI count.
Each layout uses its own np_spkpt=32 run as the reference:
    speedup = T(reference) / T(run)
    efficiency = speedup / (MPI(run) / MPI(reference))
Elapsed times use start/end timestamps, matching the original comparison.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import datetime
import os
from pathlib import Path
import re

os.environ.setdefault("MPLCONFIGDIR", f"/tmp/matplotlib-{os.getuid()}")

import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator
from matplotlib.transforms import Bbox


ROOT = Path(__file__).resolve().parent
REFERENCE = 32
K_COUNTS = (32, 64, 128, 256, 512, 1024)
OUTPUT_STEM = "comparison"
VALUE_FONT_SIZE = 16


@dataclass(frozen=True)
class Layout:
    directory: str
    label: str
    factors: tuple[int, int, int]  # npband, npspinor, npfft
    color: str
    marker: str


@dataclass(frozen=True)
class Run:
    np_spkpt: int
    mpi_ranks: int
    elapsed_seconds: float
    input_path: Path
    output_path: Path


LAYOUTS = (
    Layout("1-speedup_k111", "k-only (1-1-1)", (1, 1, 1), "#0072B2", "o"),
    Layout("2-npband211", "2-1-1 (band)", (2, 1, 1), "#D55E00", "s"),
    Layout("3-npspinor121", "1-2-1 (spinor)", (1, 2, 1), "#009E73", "^"),
    Layout("4-npfft112", "1-1-2 (FFT)", (1, 1, 2), "#CC79A7", "D"),
)


def integer_variable(text: str, name: str) -> int:
    match = re.search(rf"^\s*{re.escape(name)}\s+(\d+)\b", text, re.MULTILINE)
    if match is None:
        raise ValueError(f"Missing input variable: {name}")
    return int(match.group(1))


def elapsed_seconds(text: str) -> float:
    start = re.search(r"^start_datetime:\s*(.+)$", text, re.MULTILINE)
    end = re.search(r"^end_datetime:\s*(.+)$", text, re.MULTILINE)
    if start and end:
        fmt = "%a %b %d %H:%M:%S %Y"
        seconds = (
            datetime.strptime(end.group(1).strip(), fmt)
            - datetime.strptime(start.group(1).strip(), fmt)
        ).total_seconds()
    else:
        matches = re.findall(
            r"Proc\.\s*0 individual time \(sec\):\s*cpu=\s*[0-9.eE+-]+"
            r"\s*wall=\s*([0-9.eE+-]+)", text,
        )
        if not matches:
            raise ValueError("Missing completed elapsed timing")
        seconds = float(matches[-1])
    if seconds <= 0:
        raise ValueError(f"Invalid elapsed time: {seconds}")
    return seconds


def load_layout(layout: Layout) -> dict[int, Run]:
    runs = {}
    for input_path in sorted((ROOT / layout.directory).glob("k*.abi")):
        source = input_path.read_text(errors="replace")
        output_path = input_path.with_suffix(".out")
        text = output_path.read_text(errors="replace")
        if "Calculation completed." not in text or "--- !ERROR" in text:
            raise ValueError(f"Run did not complete successfully: {output_path}")
        if integer_variable(source, "nstep") != 1:
            raise ValueError(f"Expected nstep=1: {input_path}")
        factors = tuple(integer_variable(source, v) for v in ("npband", "npspinor", "npfft"))
        if factors != layout.factors:
            raise ValueError(f"Unexpected parallel layout in {input_path}: {factors}")
        mpi = re.search(r"^mpi_procs:\s*(\d+)\s*$", text, re.MULTILINE)
        if mpi is None:
            raise ValueError(f"Missing mpi_procs: {output_path}")
        n = integer_variable(source, "np_spkpt")
        ranks = int(mpi.group(1))
        if ranks != n * factors[0] * factors[1] * factors[2]:
            raise ValueError(f"MPI count disagrees with the requested layout: {output_path}")
        if n in runs:
            raise ValueError(f"Duplicate np_spkpt={n}: {layout.directory}")
        runs[n] = Run(n, ranks, elapsed_seconds(text), input_path, output_path)
    if set(runs) != set(K_COUNTS):
        raise ValueError(f"Expected np_spkpt={K_COUNTS} in {layout.directory}, found {sorted(runs)}")
    return runs


def configure_x(ax) -> None:
    ax.set_xscale("log", base=2)
    ax.xaxis.set_major_locator(FixedLocator(K_COUNTS))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
    ax.xaxis.set_minor_locator(NullLocator())
    ax.set_xlabel(r"k-point parallelization $np\_spkpt$")
    ax.set_xlim(27, 1215)
    ax.grid(True, which="major", linestyle=":", alpha=0.35)
    ax.set_axisbelow(True)
    ax.tick_params(which="both", direction="in", length=5,
                   top=False, right=False, labeltop=False, labelright=False)
    ax.spines["top"].set_visible(True)
    ax.spines["right"].set_visible(True)


def plain_log_y(ax, ticks) -> None:
    ax.set_yscale("log", base=2)
    ax.yaxis.set_major_locator(FixedLocator(ticks))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
    ax.yaxis.set_minor_locator(NullLocator())


def annotate_values(ax, series, value_format: str) -> None:
    """Move each column of colored values together into a clear vertical gap."""
    ax.figure.canvas.draw()
    renderer = ax.figure.canvas.get_renderer()
    font = FontProperties(size=VALUE_FONT_SIZE, weight="bold")
    points_per_pixel = 72 / ax.figure.dpi
    gap = (VALUE_FONT_SIZE + 6) / points_per_pixel
    margin = 10 / points_per_pixel
    bottom = ax.bbox.ymin + margin
    top = ax.bbox.ymax - margin
    # Check complete curve segments, including the ideal reference lines.
    paths = [line.get_transform().transform_path(line.get_path())
             for line in ax.lines]
    legend = ax.get_legend()
    legend_box = legend.get_window_extent(renderer).padded(margin) if legend else None
    occupied = []
    for index, x_value in enumerate(K_COUNTS):
        points = sorted(
            [(ax.transData.transform((x_value, values[index]))[1], layout, values[index])
             for layout, values in series], key=lambda point: point[0]
        )
        right_edge = index == len(K_COUNTS) - 1
        horizontal_offset = -11 if right_edge else (11 if index == 0 else 0)
        alignment = "right" if right_edge else ("left" if index == 0 else "center")
        sizes = [renderer.get_text_width_height_descent(value_format.format(value), font, False)
                 for _, _, value in points]
        width = max(size[0] for size in sizes)
        text_height = max(size[1] for size in sizes)
        height = text_height + (len(points) - 1) * gap
        anchor_x = ax.transData.transform((x_value, points[0][2]))[0]
        anchor_x += horizontal_offset / points_per_pixel
        left = anchor_x - (width if right_edge else (0 if index == 0 else width / 2))
        target = sum(point[0] for point in points) / len(points)

        def placement_score(group_bottom):
            box = Bbox.from_bounds(left, group_bottom, width, height).padded(6)
            collisions = sum(path.intersects_bbox(box, filled=False) for path in paths)
            collisions += 20 * sum(box.overlaps(previous) for previous in occupied)
            if legend_box is not None and box.overlaps(legend_box):
                collisions += 10
            return collisions, abs(group_bottom + height / 2 - target)

        # Search above and below the points while keeping all four rows together.
        candidates = [bottom + (top - bottom - height) * step / 200
                      for step in range(201)]
        group_bottom = min(candidates, key=placement_score)
        occupied.append(Bbox.from_bounds(left, group_bottom, width, height).padded(2))
        for row, (point_y, layout, value) in enumerate(points):
            label_y = group_bottom + text_height / 2 + row * gap
            dy = (label_y - point_y) * points_per_pixel
            ax.annotate(
                value_format.format(value), xy=(x_value, value),
                xytext=(horizontal_offset, dy), textcoords="offset points",
                ha=alignment, va="center",
                fontsize=VALUE_FONT_SIZE, fontweight="bold", color=layout.color,
                zorder=5,
            )


def main() -> None:
    data = {layout.directory: load_layout(layout) for layout in LAYOUTS}
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 20,
        "axes.labelsize": 20, "axes.titlesize": 21,
        "xtick.labelsize": 18, "ytick.labelsize": 18,
        "legend.fontsize": 16, "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    figures = [plt.subplots(figsize=(11, 8)) for _ in range(3)]
    axes = [ax for _, ax in figures]
    series_by_metric = [[] for _ in axes]
    rows = []
    for layout in LAYOUTS:
        runs = data[layout.directory]
        reference = runs[REFERENCE]
        times, speedups, efficiencies = [], [], []
        for n in K_COUNTS:
            run = runs[n]
            speedup = reference.elapsed_seconds / run.elapsed_seconds
            efficiency = speedup / (run.mpi_ranks / reference.mpi_ranks)
            times.append(run.elapsed_seconds / 3600)
            speedups.append(speedup)
            efficiencies.append(100 * efficiency)
            rows.append({
                "layout": layout.label, "directory": layout.directory,
                "npband": layout.factors[0], "npspinor": layout.factors[1],
                "npfft": layout.factors[2], "np_spkpt": n,
                "mpi_ranks": run.mpi_ranks, "elapsed_s": run.elapsed_seconds,
                "reference_np_spkpt": REFERENCE,
                "reference_mpi_ranks": reference.mpi_ranks,
                "reference_elapsed_s": reference.elapsed_seconds,
                "speedup": speedup, "efficiency_percent": 100 * efficiency,
                "input_file": str(run.input_path.relative_to(ROOT)),
                "output_file": str(run.output_path.relative_to(ROOT)),
            })
        for ax, series, values in zip(axes, series_by_metric, (times, speedups, efficiencies)):
            ax.plot(K_COUNTS, values, marker=layout.marker, markersize=9,
                            linewidth=2.3, color=layout.color, label=layout.label,
                            markeredgecolor="white", markeredgewidth=0.6)
            series.append((layout, values))
        print(f"{layout.label:20s} | reference {reference.mpi_ranks:4d} MPI, "
              f"{reference.elapsed_seconds:6.0f} s | final speedup {speedups[-1]:6.3f}, "
              f"efficiency {efficiencies[-1]:5.1f}%")

    axes[1].plot(K_COUNTS, [n / REFERENCE for n in K_COUNTS],
                 color="0.35", linestyle="--", linewidth=1.7, zorder=1,
                 label="Ideal scaling")
    axes[2].axhline(100, color="0.35", linestyle="--", linewidth=1.7, zorder=1,
                   label="Ideal: 100%")
    for ax in axes:
        configure_x(ax)
    plain_log_y(axes[0], (0.025, 0.05, 0.1, 0.2, 0.4, 0.8))
    axes[0].set_ylim(0.02, 0.9)
    axes[0].set_ylabel("Elapsed wall time (hours)")
    axes[0].set_title(r"Absolute speed at equal $np\_spkpt$", pad=16)
    axes[0].legend(loc="upper right", frameon=True, framealpha=0.95)
    plain_log_y(axes[1], (1, 2, 4, 8, 16, 32))
    axes[1].set_ylim(0.82, 40)
    axes[1].set_ylabel(r"Speedup $T_{\rm ref}/T$")
    axes[1].set_title("Strong-scaling speedup", pad=16)
    axes[1].legend(loc="upper left", frameon=True, framealpha=0.95)
    axes[2].set_ylim(0, 116)
    axes[2].set_yticks((0, 20, 40, 60, 80, 100))
    axes[2].set_ylabel("Parallel efficiency (%)")
    axes[2].set_title("Strong-scaling efficiency", pad=16)
    axes[2].legend(loc="lower left", frameon=True, framealpha=0.95)
    for (fig, ax), metric, series, value_format in zip(
        figures, ("elapsed_time", "speedup", "efficiency"), series_by_metric,
        ("{:.3f}", "{:.2f}", "{:.1f}%"),
    ):
#        fig.subplots_adjust(left=0.15, right=0.97, top=0.91, bottom=0.21)
        annotate_values(ax, series, value_format)
        for suffix in ("png", "pdf"):
            path = ROOT / f"{OUTPUT_STEM}_{metric}.{suffix}"
            fig.savefig(path, dpi=300, bbox_inches="tight", facecolor="white")
            print(f"Saved: {path}")
    csv_path = ROOT / f"{OUTPUT_STEM}.csv"
    with csv_path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved: {csv_path}")
    plt.show()


if __name__ == "__main__":
    main()
