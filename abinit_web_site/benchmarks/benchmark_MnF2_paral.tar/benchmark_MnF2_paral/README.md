# MnF2 benchmark: parallelization levels at equal np_spkpt

Data behind the figure `comparison_elapsed_time.png` shown on the ABINIT
benchmark page (https://www.abinit.org/benchmark.html).

## What is tested

Elapsed wall time of a ground-state run as a function of the k-point
parallelization `np_spkpt` (32 to 1024), for four parallel layouts
`npband`-`npspinor`-`npfft`:

| Directory        | Layout | Second parallelization level | MPI processes   |
|------------------|--------|------------------------------|-----------------|
| `1-speedup_k111` | 1-1-1  | none (k-points only)         | `np_spkpt`      |
| `2-npband211`    | 2-1-1  | bands                        | 2 x `np_spkpt`  |
| `3-npspinor121`  | 1-2-1  | spinor components            | 2 x `np_spkpt`  |
| `4-npfft112`     | 1-1-2  | FFT                          | 2 x `np_spkpt`  |

All runs use `paral_kgb 1` and `bandpp 40`.

## System

MnF2, 12 atoms, non-collinear magnetism (`nspinor 2`, `nspden 4`,
no spin-orbit coupling), constrained DFT on the direction of the Mn magnetic
moments (`constraint_kind 4 0`). 160 bands, `ecut` 60 Ha, 10x10x5 k-point grid
without symmetries (500 k-points), FFT grid 64x64x90. LDA with ONCVPSP
norm-conserving pseudopotentials (`Mn-sp-r_LDA_1012_dojov0.4.psp8`, `F_r.psp8`,
both included).

Each run performs a single SCF step (`nstep 1`, `nline 11`), so the run is not
converged; only the timing is of interest.

## Files

- `kN.abi`: input file. `N` is the total number of MPI processes, not `np_spkpt`.
- `kN.abo`: main ABINIT output file.
- `kN.out`: ABINIT log file, with the build information and the start and end timestamps.
- `compare_speedup_efficiency.py`: script producing the figure and a CSV file.

## How the time is measured

The elapsed time is the difference between `end_datetime` and `start_datetime`
in the log file, i.e. the total wall time of the run (initialization, one SCF
step and forces). It agrees within one second with the "Proc. 0 individual
time" printed at the end of the output file.

## Remarks

- There are only 500 k-points, so `np_spkpt` = 1024 brings nothing more than
  `np_spkpt` = 512.
- The LOBPCG block size is `npband` x `bandpp`. Since `bandpp` is fixed to 40,
  the block size is 80 in the 2-1-1 runs and 40 in the three other layouts, and
  the total energy after the single SCF step is therefore different.

## Software and hardware

- ABINIT 10.9.2.
- GNU 11.3 compilers, `-g -O2 -march=native`, MPI, OpenBLAS, FFTW3, no OpenMP.
- Lucia supercomputer (Cenaero, Belgium): 2 x AMD EPYC 7763 64-core processors
  per node (128 cores per node), 100 Gb/s InfiniBand.
