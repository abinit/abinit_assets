#!/usr/bin/env python3
"""Plot completed b*.out Proc. 0 wall times against the input npband.

Run with Python to save PNG/PDF/CSV and display the figure with plt.show().
"""

import csv
import os
from pathlib import Path
import re

os.environ.setdefault("MPLCONFIGDIR", f"/tmp/matplotlib-{os.getuid()}")

import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator


ROOT = Path(__file__).resolve().parent
STEM = "wall_time_vs_npband"


def input_integer(text, name):
    match = re.search(rf"^\s*{re.escape(name)}\s+(\d+)\b", text, re.MULTILINE)
    if match is None:
        raise ValueError(f"Missing input variable: {name}")
    return int(match.group(1))


def main():
    rows = []
    settings = ("npband", "np_spkpt", "npspinor", "npfft", "bandpp", "nstep", "nnsclo")
    for input_path in ROOT.glob("b*.abi"):
        if not re.fullmatch(r"b\d+", input_path.stem):
            continue
        source = input_path.read_text()
        output_path = input_path.with_suffix(".out")
        output = output_path.read_text(errors="replace")
        if "Calculation completed." not in output or "--- !ERROR" in output:
            raise ValueError(f"Run did not complete successfully: {output_path}")
        matches = re.findall(
            r"Proc\.\s*0 individual time \(sec\):\s*cpu=\s*[\d.eE+-]+"
            r"\s*wall=\s*([\d.eE+-]+)", output,
        )
        mpi = re.search(r"^mpi_procs:\s*(\d+)\s*$", output, re.MULTILINE)
        if not matches or mpi is None:
            raise ValueError(f"Missing completed timing or MPI count: {output_path}")
        row = {name: input_integer(source, name) for name in settings}
        row.update(wall_time_s=float(matches[-1]), mpi_ranks=int(mpi.group(1)),
                   input_file=input_path.name, output_file=output_path.name)
        expected = row["npband"] * row["np_spkpt"] * row["npspinor"] * row["npfft"]
        if row["mpi_ranks"] != expected or row["wall_time_s"] <= 0:
            raise ValueError(f"Invalid MPI count or timing: {output_path}")
        rows.append(row)
    rows.sort(key=lambda row: row["npband"])
    if not rows or len({row["npband"] for row in rows}) != len(rows):
        raise ValueError("Missing data or duplicate npband values")
    for name in settings[1:]:
        if len({row[name] for row in rows}) != 1:
            raise ValueError(f"Cannot label {name} as fixed: inputs differ")

    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 18,
        "axes.labelsize": 20, "axes.titlesize": 21,
        "xtick.labelsize": 18, "ytick.labelsize": 18,
        "pdf.fonttype": 42, "ps.fonttype": 42,
    })
    fig, ax = plt.subplots(figsize=(11, 8))
    bands = [row["npband"] for row in rows]
    times = [row["wall_time_s"] for row in rows]
    color = "#0072B2"
    ax.plot(bands, times, "o-", color=color, linewidth=3, markersize=18,
            markeredgecolor="white", markeredgewidth=0.7)
    ax.set_xscale("log", base=2)
    ax.xaxis.set_major_locator(FixedLocator(bands))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
    ax.xaxis.set_minor_locator(NullLocator())
    # Y-axis: log2 scale with normal numeric tick labels
    ax.set_yscale("log", base=2)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}"))
    ax.yaxis.set_minor_locator(NullLocator())
    ax.set_ylim(min(times) / 1.25, max(times) * 1.16)
    ax.set_xlabel(r"Band parallelization $npband$")
    ax.set_ylabel("Wall time (seconds)")
    ax.set_title("MnF2: wall time vs npband", pad=16)
    ax.grid(True, which="major", linestyle=":", alpha=0.35)
    ax.set_axisbelow(True)
    ax.tick_params(which="both", direction="in", top=False, right=False)
    ax.spines["top"].set_visible(True)
    ax.spines["right"].set_visible(True)
    for i, (band, time) in enumerate(zip(bands, times)):
      first = (i == 0)
      ax.annotate(
        f"{time:.1f} s",
        xy=(band, time),
        xytext=(56, 0) if first else (-10, -36),
        textcoords="offset points",
        ha="center",
        va="bottom",
        fontsize=20,
        fontweight="bold",
        color=color
      )
    fixed = rows[0]
    for suffix in ("png", "pdf"):
        path = ROOT / f"{STEM}.{suffix}"
        fig.savefig(path, dpi=300, bbox_inches="tight", facecolor="white")
        print(f"Saved: {path}")
    with (ROOT / f"{STEM}.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for row in rows:
        print(f"npband={row['npband']:2d}, MPI={row['mpi_ranks']:3d}, "
              f"wall={row['wall_time_s']:.1f} s")
    plt.show()


if __name__ == "__main__":
    main()
