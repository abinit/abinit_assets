# MnF2 benchmark: wall time versus npband

Data behind the figure `wall_time_vs_npband.png` shown on the ABINIT benchmark
page (https://www.abinit.org/benchmark.html).

## What is tested

Wall time of a ground-state run as a function of the band parallelization
`npband` (1, 2, 4, 8, 16), with `np_spkpt 32`, `npspinor 1`, `npfft 1`,
`bandpp 10` and `paral_kgb 1`. The number of MPI processes is 32 x `npband`
(32 to 512).

| npband | MPI processes | Wall time (s) |
|--------|---------------|---------------|
| 1      | 32            | 1934.9        |
| 2      | 64            | 1295.4        |
| 4      | 128           | 790.1         |
| 8      | 256           | 482.9         |
| 16     | 512           | 342.1         |

## System

MnF2, 12 atoms, non-collinear magnetism (`nspinor 2`, `nspden 4`,
no spin-orbit coupling), constrained DFT on the direction of the Mn magnetic
moments (`constraint_kind 4 0`). 160 bands, `ecut` 60 Ha, 10x10x5 k-point grid
without symmetries (500 k-points), FFT grid 64x64x90. LDA with ONCVPSP
norm-conserving pseudopotentials (`Mn-sp-r_LDA_1012_dojov0.4.psp8`, `F_r.psp8`,
both included).

Each run performs a single SCF step (`nstep 1`, `nline 11`), so the run is not
converged; only the timing is of interest.

## Files

- `bN.abi`: input file, where `N` is `npband`.
- `bN.abo`: main ABINIT output file.
- `bN.out`: ABINIT log file (standard output), with the build information.
- `plot_wall_time_vs_npband.py`: script producing the figure and a CSV file.

## How the time is measured

The wall time is the "Proc. 0 individual time" printed at the end of the run,
i.e. the total wall time of the run (initialization, one SCF step and forces).

## Remark

The LOBPCG block size is `npband` x `bandpp`. Since `bandpp` is fixed to 10,
the block size goes from 10 (`npband` 1) to 160 (`npband` 16), and the total
energy after the single SCF step is therefore different from one run to the
other.

## Software and hardware

- ABINIT 10.9.2.
- GNU 11.3 compilers, `-g -O2 -march=native`, MPI, OpenBLAS, FFTW3, no OpenMP.
- Lucia supercomputer (Cenaero, Belgium): 2 x AMD EPYC 7763 64-core processors
  per node (128 cores per node), 100 Gb/s InfiniBand.
